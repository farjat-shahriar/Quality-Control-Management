<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Hammersmith+One&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css">
    <title>TQM-PSAI</title>
</head>

<body>

     @include('nevbar')

    <!-- Title -->
    <div class="container ">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center">The Govt ABCD College</h2>
                <p>Lorem Ipsum is simply dummy text of the printimbled ecimen book. It has survived not onlyeap into
                    electronic typesetting, remaining essentially unchanged. It was
                    popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum </p>
            </div>
        </div>
    </div>
    <!-- Title -->
    <hr>

    <!-- School Info Show Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img id="college" class="" src="image/college.jpg" alt="">
            </div>
            <div class="col-md-6">
                <h4>College Information</h4>
                <hr>
                <p> <strong>Name:</strong> The ABCD High College</p>
                <p> <strong>Established:</strong> 1956</p>
                <p> <strong>Location:</strong> Dhanmondi,Dhaka</p>
                <p> <strong>Division:</strong> Dhaka</p>
                <p> <strong>Current Student:</strong> 1900</p>
                <p> <strong>Contact:</strong> abcd@gmial.com</p>
                <p> <strong>Website:</strong> <a href="www.abcd.com" target="_blank"> www.abcd.com</a> </p>
                <p> <strong>Pricipal Name:</strong> Md Alis</p>
            </div>
        </div>
    </div>
    <!-- School Info Show End -->

    <hr>

    <!-- Admission Fee Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-center">Yearly Tuition Range</h3>
                <table class="table">
                    <thead class="text-center">
                        <tr>
                            <th scope="col">Fee Name</th>
                            <th scope="col">Monthly</th>
                            <th scope="col">Yearly</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr>
                            <th>Trimseter Fee</th>
                            <td>&#2547; 500</td>
                            <td>&#2547; 5000</td>
                        </tr>
                        <tr>
                            <th>Library Fee</th>
                            <td>&#2547; 500</td>
                            <td>&#2547; 5000</td>
                        </tr>
                        <tr>
                            <th>Field Fee</th>
                            <td>&#2547; 500</td>
                            <td>&#2547; 5000</td>
                        </tr>
                        <tr>
                            <th>SANC</th>
                            <td>&#2547; 500</td>
                            <td>&#2547; 5000</td>
                        </tr>
                        <tr>
                            <th>Total: </th>
                            <td><strong>&#2547; 500</strong> </td>
                            <td><strong>&#2547; 5000</strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Admission Fee End -->
    <hr>


    <!-- Study Areas  Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-center">Study Areas</h3>
                <table class="table">
                    <thead class="text-center">
                        <tr>
                            <th scope="col">Group</th>
                            <th scope="col">PSC</th>
                            <th scope="col">JSC</th>
                            <th scope="col">SSC</th>
                            <th scope="col">HSC</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr>
                            <th>Arts</th>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                        </tr>
                        <tr>
                            <th>Comarts</th>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                        </tr>
                        <tr>
                            <th>Science</th>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Study Areas End -->
    <hr>
    <!-- Admission and Facilitys start -->
    <div class="container">
        <div class="row">
            <div class="col-md-4 text-center">
                <h3>Admissions</h3>
                <p><Strong>Gender: </Strong>Male <i class="fa fa-check-circle"></i>  Female<i class="fa fa-times"></i> </p>
                <p><Strong>International Students: </Strong> <i class="fa fa-times"></i> </p>
                <p><Strong>Selection Type: </Strong>  <i class="fa fa-times"></i> </p> 
                <p><Strong>Admission Rate: </Strong>  &#2547; 500 </p>
                <p><Strong>Admission Office: </Strong> 	Rua Adjacente a Av. 21 de Janeiro </p>
                <p><Strong>Contact: </Strong> +880-123453453 </p>
            </div>
            <div class="col-md-4 text-center">
                <h3>Facilities and Services</h3>
                <p><Strong>Library: </Strong><i class="fa fa-check-circle"></i> </p>
                <p><Strong>Housing: </Strong> <i class="fa fa-times"></i> </p>
                <p><Strong>Sport Facilities: </Strong>  <i class="fa fa-times"></i> </p> 
                <p><Strong>Financial Aids: </Strong>  <i class="fa fa-check-circle"></i> </p>
                <p><Strong>Study Abroad: </Strong> 	<i class="fa fa-check-circle"></i> </p>
                <p><Strong>Academic Counseling: </Strong>  <i class="fa fa-times"></i> </p>
            </div>
            <div class="col-md-4 text-center">
                <h3>Size and Profile</h3>
                <p><Strong>Student Enrollment: </Strong>2,000-2,999 </p>
                <p><Strong>Academic Staff: </Strong> 100-199 </p>
                <p><Strong>Control Type: </Strong>  Private </p> 
                <p><Strong>Entity Type: </Strong>  Not reported </p>
                <p><Strong>Campus Setting: </Strong> Urban </p>
                <p><Strong>Religious Affiliation: </Strong>  None </p>
            </div>
        </div>
    </div>
    <!-- Admission and Faculitys End -->
    <hr>
    <!-- School Previous Data Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <canvas id="myChart" width="400" height="400"></canvas>
                <h3 class="text-center">GPA 5 Per Year</h3>
            </div>
            <div class="col-md-6">
                <canvas id="myChart3" width="400" height="400"></canvas>
                <h3 class="text-center">Ranking Per Year</h3>
            </div>
        </div>
    </div>
    <!-- School Previous Data End -->


    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <h6>About</h6>
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printimbled ecimen book. It has
                        survived not only five
                        centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It
                        was
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                        and
                        more recently with desktop publishing software like Aldus PageMaker including versions of Lorem
                        Ipsum.</p>
                </div>

                <div class="col-xs-
                6 col-md-3">
                    <h6>Categories</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/category/c-language/">C</a></li>
                        <li><a href="http://scanfcode.com/category/front-end-development/">UI Design</a></li>
                        <li><a href="http://scanfcode.com/category/back-end-development/">PHP</a></li>
                        <li><a href="http://scanfcode.com/category/java-programming-language/">Java</a></li>
                        <li><a href="http://scanfcode.com/category/android/">Android</a></li>
                        <li><a href="http://scanfcode.com/category/templates/">Templates</a></li>
                    </ul>
                </div>

                <div class="col-xs-6 col-md-3">
                    <h6>Quick Links</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/about/">About Us</a></li>
                        <li><a href="http://scanfcode.com/contact/">Contact Us</a></li>
                        <li><a href="http://scanfcode.com/contribute-at-scanfcode/">Contribute</a></li>
                        <li><a href="http://scanfcode.com/privacy-policy/">Privacy Policy</a></li>
                        <li><a href="http://scanfcode.com/sitemap/">Sitemap</a></li>
                    </ul>
                </div>
            </div>
            <hr>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <p class="copyright-text">Copyright &copy; 2021 All Rights Reserved by
                        <a href="#">Abc</a>.
                    </p>
                </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                    <ul class="social-icons">
                        <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
    <script src="https://use.fontawesome.com/c1b9851178.js"></script>
    <script src="js/singleInstitution.js"></script>
</body>

</html>