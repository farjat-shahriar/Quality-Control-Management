<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Hammersmith+One&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css">
    <title>TQM-PSAI</title>
</head>

<body>

     @include('nevbar')

    <!-- Title -->
    <div class="container ">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center">Government Laboratory High School</h2>
                <p>The Government Laboratory High School is one of the top schools in Bangladesh. It is situated at Dhanmondi in Dhaka, Bangladesh. Government Laboratory High School was established in 1961 and Muhammad Osman Gani was the founder of this school. It has excellent learning facilities very bright result. The motto of this school is “Light, More Light”.
                    To know more, visit the official <a href="http://www.glabdhaka.edu.bd">website</a>. </p>
            </div>
        </div>
    </div>
    <!-- Title -->
    <hr>

    <!-- School Info Show Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <img id="school" class="" src="image/school.jpg" alt="">
            </div>
            <div class="col-md-6">
                <h4>School Information</h4>
                <hr>
                <p> <strong>Name:</strong> Government Laboratory High School</p>
                <p> <strong>Established:</strong> September 3, 1961 </p>
                <p> <strong>Location:</strong> New Market,Dhaka</p>
                <p> <strong>Division:</strong> Dhaka</p>
                <p> <strong>Current Student:</strong>2630</p>
                <p> <strong>Contact:</strong> anischp@gmial.com</p>
                <p> <strong>phone:</strong> 01715269085, 02-41060052</p>
                <p> <strong>Website:</strong> <a href="http://www.glabdhaka.edu.bd" > www.glabdhaka.edu.bd</a> </p>
                <p> <strong>Pricipal Name:</strong> Md Abu Sayed Vuian</p>
            </div>
        </div>
    </div>
    <!-- School Info Show End -->

    <hr>

    <!-- Admission Fee Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-center">Yearly Tuition Range</h3>
                <table class="table">
                    <thead class="text-center">
                        <tr>
                            <th scope="col">Fee Name</th>
                            <th scope="col">Monthly</th>
                            <th scope="col">Yearly</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr>
                            <th>Trimseter Fee</th>
                            <td>&#2547; 20</td>
                            <td>&#2547; 240</td>
                        </tr>
                        <tr>
                            <th>Library Fee</th>
                            <td>&#2547; 50</td>
                            <td>&#2547; 600</td>
                        </tr>
                        <tr>
                            <th>Field Fee</th>
                            <td>&#2547; 0</td>
                            <td>&#2547; 0</td>
                        </tr>
                        <tr>
                            <th>Tiffine</th>
                            <td>&#2547; 50</td>
                            <td>&#2547; 600</td>
                        </tr>
                        <tr>
                            <th>Others</th>
                            <td>&#2547; 150</td>
                            <td>&#2547; 1800</td>
                        </tr>
                        <tr>
                            <th>Total: </th>
                            <td><strong>&#2547; 270</strong> </td>
                            <td><strong>&#2547; 3240</strong></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Admission Fee End -->
    <hr>


    <!-- Study Areas  Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h3 class="text-center">Study Areas</h3>
                <table class="table">
                    <thead class="text-center">
                        <tr>
                            <th scope="col">Group</th>
                            <th scope="col">PSC</th>
                            <th scope="col">JSC</th>
                            <th scope="col">SSC</th>
                            <th scope="col">HSC</th>
                        </tr>
                    </thead>
                    <tbody class="text-center">
                        <tr>
                            <th>Arts</th>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                        </tr>
                        <tr>
                            <th>Comarts</th>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-times"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                        </tr>
                        <tr>
                            <th>Science</th>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                            <td> <i class="fa fa-check-circle"></i></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Study Areas End -->
    <hr>
    <!-- Admission and Facilitys start -->
    <div class="container">
        <div class="row">
            <div class="col-md-4 text-center">
                <h3>Admissions</h3>
                <p><Strong>Gender: </Strong>Male <i class="fa fa-check-circle"></i> Female<i class="fa fa-times"></i>
                </p>
                <p><Strong>International Students: </Strong> <i class="fa fa-times"></i> </p>
                <p><Strong>Selection Type: </Strong> <i class="fa fa-times"></i> </p>
                <p><Strong>Admission Rate: </Strong> &#2547; 500 </p>
                <p><Strong>Admission Office: </Strong> https://gsa.teletalk.com.bd </p>
                <p><Strong>Contact: </Strong> 02-41060052 </p>
            </div>
            <div class="col-md-4 text-center">
                <h3>Facilities and Services</h3>
                <p><Strong>Library: </Strong><i class="fa fa-check-circle"></i> </p>
                <p><Strong>Housing: </Strong> <i class="fa fa-times"></i> </p>
                <p><Strong>Sport Facilities: </Strong> <i class="fa fa-check-circle"></i> </p>
                <p><Strong>Financial Aids: </Strong> <i class="fa fa-check-circle"></i> </p>
                <p><Strong>Study Abroad: </Strong> <i class="fa fa-check-circle"></i> </p>
                <p><Strong>Academic Counseling: </Strong> <i class="fa fa-check-circle"></i> </p>
            </div>
            <div class="col-md-4 text-center">
                <h3>Size and Profile</h3>
                <p><Strong>Student Enrollment: </Strong>2,000-2,999 </p>
                <p><Strong>Academic Staff: </Strong> 100-199 </p>
                <p><Strong>Control Type: </Strong> Private </p>
                <p><Strong>Entity Type: </Strong> Not reported </p>
                <p><Strong>Campus Setting: </Strong> Urban </p>
                <p><Strong>Religious Affiliation: </Strong> None </p>
            </div>
        </div>
    </div>
    <!-- Admission and Faculitys End -->
    <hr>
    <!-- School Previous Data Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <canvas id="myChart" width="400" height="400"></canvas>
                <h3 class="text-center">GPA 5 Per Year</h3>
            </div>
            <div class="col-md-6">
                <canvas id="myChart3" width="400" height="400"></canvas>
                <h3 class="text-center">Ranking Per Year</h3>
            </div>
        </div>
    </div>
    <!-- School Previous Data End -->


    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <h6>About</h6>
                    <p class="text-justify">The Government Laboratory High School is one of the top schools in Bangladesh. It is situated at Dhanmondi in Dhaka, Bangladesh. Government Laboratory High School was established in 1961 and Muhammad Osman Gani was the founder of this school. It has excellent learning facilities very bright result. The motto of this school is “Light, More Light”.
                    To know more, visit the official <a href="http://www.glabdhaka.edu.bd">website</a>. </p>
                </div>

               

                
            </div>
            <hr>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <p class="copyright-text">Copyright &copy; 2021 All Rights Reserved by
                        <a href="#">LT</a>.
                    </p>
                </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                    <ul class="social-icons">
                        <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
    <script src="https://use.fontawesome.com/c1b9851178.js"></script>
    <script src="js/singleInstitution.js"></script>
</body>

</html>