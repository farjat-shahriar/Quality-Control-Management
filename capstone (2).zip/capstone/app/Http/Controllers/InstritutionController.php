<?php

namespace App\Http\Controllers;


use App\Http\Controllers\Controller;


use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

use storage\framework\sessions;
use App\Instritution;





class InstritutionController extends Controller
{
    //
    
    public function addjoin (Request $request) {
        
        
       
       $ins=new Instritution();
       $ins->name=$request->ins_name;
       $ins->established=$request->established;
       $ins->division=$request->division;
       $ins->type=$request->type;
       $ins->location=$request->location;
       $ins->email=$request->email;
               
       $ins->password=md5($request->pass);
       
       $ins->save();
       
       return view("joinus");
       
        
        
    }
}
