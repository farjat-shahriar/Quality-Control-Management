<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Hammersmith+One&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css">
    <title>TQM-PSAI</title>
</head>

<body>

     <?php echo $__env->make('nevbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Title -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center">Find The Best School in Your Area</h2>
            </div>
        </div>
    </div>
    <!-- Title -->

    <!-- Search Div Start -->
    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="inputGroupSelect01">Division</label>
                    </div>
                    <select class="custom-select" id="inputGroupSelect01">
                        <option selected>All...</option>
                        <option value="Barisal">Barisal</option>
                        <option value="Chittagong ">Chittagong </option>
                        <option value="Dhaka">Dhaka</option>
                        <option value="Khulna">Khulna</option>
                        <option value="Mymensingh">Mymensingh</option>
                        <option value="Rajshahi">Rajshahi</option>
                        <option value="Rajshahi">Sylhet</option>
                        <option value="Rajshahi">Rangpur</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="inputGroupSelect01">Group</label>
                    </div>
                    <select class="custom-select" id="inputGroupSelect01">
                        <option selected>All...</option>
                        <option value="Arts ">Arts </option>
                        <option value="Comarts">Comarts</option>
                        <option value="Science">Science</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="inputGroupSelect01">Sort Type</label>
                    </div>
                    <select class="custom-select" id="inputGroupSelect01">
                        <option selected>All...</option>
                        <option value="Arts ">GPA 5 </option>
                        <option value="Comarts">Area</option>
                        <option value="Science">Education</option>
                    </select>
                </div>
            </div>
            <div class="col-md-3 ">
                <button class="btn_cos_01 pull-right">Find The Best One</button>
            </div>
        </div>
    </div>
    <!-- Search Div End -->

    <hr>
      <!-- School Data show start -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">     
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Rank</th>
                            <th scope="col">School Name</th>
                            <th scope="col">Location</th>
                            <th scope="col">Division</th>
                            <th scope="col">More</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Government Laboratory High School</td>
                            <td>New Market</td>
                            <td>Dhaka</td>
                            <td> <a href="singleSchool">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Viqarunnisa Noon School & College</td>
                            <td>Baily Road</td>
                            <td>Dhaka</td>
                            <td> <a href="https://www.vnsc.edu.bd">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Rajuk Uttara Model School & College</td>
                            <td>Uttara</td>
                            <td>Dhaka</td>
                            <td> <a href="https://rajukcollege.net">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">4</th>
                            <td>Dhaka Residential Model School & College</td>
                            <td>Mohammadpur</td>
                            <td>Dhaka</td>
                            <td> <a href="http://www.drmc.edu.bd">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">5</th>
                            <td>Chittagong Collegiate School & College</td>
                            <td>Ice Factory Rd</td>
                            <td>Chittagong</td>
                            <td> <a href="https://ctgcs.edu.bd">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">6</th>
                            <td>Bir Shreshtha Noor Mohammad Public College</td>
                            <td>Dhanmondi</td>
                            <td>Dhaka</td>
                            <td> <a href="http://www.noormohammadcollege.ac.bd">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">7</th>
                            <td>Holy Cross Girls’ High School, Dhaka</td>
                            <td>Farmgate</td>
                            <td>Dhaka</td>
                            <td> <a href="https://en.wikipedia.org/wiki/Holy_Cross_Girls%27_High_School_(Dhaka)">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">8</th>
                            <td>Monipur High School & College</td>
                            <td>Mirpur</td>
                            <td>Dhaka</td>
                            <td> <a href="https://en.wikipedia.org/wiki/Monipur_High_School_and_College">Details>></a></td>
                        </tr>
                        <tr>
                            <th scope="row">9</th>
                            <td>St. Joseph Higher Secondary School</td>
                            <td>Mohammadpur</td>
                            <td>Dhaka</td>
                            <td> <a href="http://sjs.edu.bd">Details>></a></td>
                        </tr>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- School Data show end -->

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <h6>About</h6>
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printimbled ecimen book. It has
                        survived not only five
                        centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It
                        was
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                        and
                        more recently with desktop publishing software like Aldus PageMaker including versions of Lorem
                        Ipsum.</p>
                </div>

                <div class="col-xs-6 col-md-3">
                    <h6>Categories</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/category/c-language/">C</a></li>
                        <li><a href="http://scanfcode.com/category/front-end-development/">UI Design</a></li>
                        <li><a href="http://scanfcode.com/category/back-end-development/">PHP</a></li>
                        <li><a href="http://scanfcode.com/category/java-programming-language/">Java</a></li>
                        <li><a href="http://scanfcode.com/category/android/">Android</a></li>
                        <li><a href="http://scanfcode.com/category/templates/">Templates</a></li>
                    </ul>
                </div>

                <div class="col-xs-6 col-md-3">
                    <h6>Quick Links</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/about/">About Us</a></li>
                        <li><a href="http://scanfcode.com/contact/">Contact Us</a></li>
                        <li><a href="http://scanfcode.com/contribute-at-scanfcode/">Contribute</a></li>
                        <li><a href="http://scanfcode.com/privacy-policy/">Privacy Policy</a></li>
                        <li><a href="http://scanfcode.com/sitemap/">Sitemap</a></li>
                    </ul>
                </div>
            </div>
            <hr>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <p class="copyright-text">Copyright &copy; 2021 All Rights Reserved by
                        <a href="#">Abc</a>.
                    </p>
                </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                    <ul class="social-icons">
                        <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
</body>

</html><?php /**PATH G:\xampp 3.0\htdocs\capstone\resources\views/allSchool.blade.php ENDPATH**/ ?>