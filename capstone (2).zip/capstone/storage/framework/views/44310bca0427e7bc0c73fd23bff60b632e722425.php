<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Hammersmith+One&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Condensed:wght@300;400&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css"
        integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <link rel="stylesheet" href="css/style.css">
    <title>TQM-PSAI</title>
</head>

<body>

     <?php echo $__env->make('nevbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Title -->
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="text-center">Join Us and Make your Institution Best</h2>
            </div>
        </div>
    </div>
    <!-- Title -->
    <hr>
    <div class="container">
        <div class="row">
            <div class="col-md-3" id="joinUs">
                <section>
                    <img class="sideImage" src="image/trophy.svg" alt="">
                    <h3>Find The best</h3>
                    <p>orem Ipsum is simply dummy text of the printimbled ecimen book. It has survived not only fiv</p>
                </section>
                <section class="joinusgap">
                    <img class="sideImage" src="image/open-book.svg" alt="">
                    <h3>Find The best</h3>
                    <p>orem Ipsum is simply dummy text of the printimbled ecimen book. It has survived not only fiv</p>
                </section>
                <section class="joinusgap">
                    <img class="sideImage" src="image/student.svg" alt="">
                    <h3>Find The best</h3>
                    <p>orem Ipsum is simply dummy text of the printimbled ecimen book. It has survived not only fiv</p>
                </section>

            </div>

            <div class="col-md-9">
                <form method="post" action="" >
                    <div class="row">
                        <div class="col-md-8">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong> Institution Name</strong></label>
                                <input type="text" class="form-control" id="exampleInputEmail1" name= "ins_name"
                                    placeholder="Institution Name">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Established</strong></label>
                                <select class="custom-select" id="inputGroupSelect01" name= "established" >
                                    <option selected>Select..</option>
                                    <?php for($i = 1900; $i < 2022; $i++): ?>
                                        <option value=<?php echo e($i); ?>><?php echo e($i); ?></option>
                                        
                                    <?php endfor; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Division</strong></label>
                                <select class="custom-select" id="inputGroupSelect01" name= "division">
                                    <option selected>Select...</option>
                                    <option value="Barisal">Barisal</option>
                                    <option value="Chittagong ">Chittagong </option>
                                    <option value="Dhaka">Dhaka</option>
                                    <option value="Khulna">Khulna</option>
                                    <option value="Mymensingh">Mymensingh</option>
                                    <option value="Rajshahi">Rajshahi</option>
                                    <option value="Rajshahi">Sylhet</option>
                                    <option value="Rajshahi">Rangpur</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Institution Type</strong></label>
                                <!-- <input type="text" class="form-control" id="exampleInputEmail1" placeholder="Established"> -->
                                <select class="custom-select" id="inputGroupSelect01" name= "type">
                                    <option selected>Select...</option>
                                    <option value="School">School</option>
                                    <option value="College">College</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Email</strong></label>
                                <input type="mail" class="form-control" id="exampleInputEmail1" name="email" placeholder="Email">     
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Location</strong></label>
                                <input type="text" class="form-control" id="exampleInputEmail1" name="location" placeholder="Location">     
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Degree Support</strong></label>
                                <br>
                                <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="option1">
                                    <label class="form-check-label" for="inlineCheckbox1">PSC</label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="option2">
                                    <label class="form-check-label" for="inlineCheckbox2">JSC</label>
                                  </div>
                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="option3">
                                    <label class="form-check-label" for="inlineCheckbox3">SSC </label>
                                  </div> 
                                  <div class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" id="inlineCheckbox4" value="option4">
                                    <label class="form-check-label" for="inlineCheckbox4">HSC</label>
                                  </div>    
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Password</strong></label>
                                <input type="password" class="form-control" id="exampleInputEmail1" name="pass" placeholder="Password">     
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="exampleInputEmail1"> <strong>Confirm Password</strong></label>
                                <input type="Password" class="form-control" id="exampleInputEmail1" name="cpass" placeholder="Confirm Password">     
                            </div>
                        </div>
                        <div class="col-md-12 ">
                            <button class="btn_cos float-right">Create Account</button>
                        </div>

                    </div>
                </form>
            </div>

        </div>
    </div>

    <footer class="site-footer">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6">
                    <h6>About</h6>
                    <p class="text-justify">Lorem Ipsum is simply dummy text of the printimbled ecimen book. It has
                        survived not only five
                        centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It
                        was
                        popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages,
                        and
                        more recently with desktop publishing software like Aldus PageMaker including versions of Lorem
                        Ipsum.</p>
                </div>

                <div class="col-xs-
            6 col-md-3">
                    <h6>Categories</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/category/c-language/">C</a></li>
                        <li><a href="http://scanfcode.com/category/front-end-development/">UI Design</a></li>
                        <li><a href="http://scanfcode.com/category/back-end-development/">PHP</a></li>
                        <li><a href="http://scanfcode.com/category/java-programming-language/">Java</a></li>
                        <li><a href="http://scanfcode.com/category/android/">Android</a></li>
                        <li><a href="http://scanfcode.com/category/templates/">Templates</a></li>
                    </ul>
                </div>

                <div class="col-xs-6 col-md-3">
                    <h6>Quick Links</h6>
                    <ul class="footer-links">
                        <li><a href="http://scanfcode.com/about/">About Us</a></li>
                        <li><a href="http://scanfcode.com/contact/">Contact Us</a></li>
                        <li><a href="http://scanfcode.com/contribute-at-scanfcode/">Contribute</a></li>
                        <li><a href="http://scanfcode.com/privacy-policy/">Privacy Policy</a></li>
                        <li><a href="http://scanfcode.com/sitemap/">Sitemap</a></li>
                    </ul>
                </div>
            </div>
            <hr>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-8 col-sm-6 col-xs-12">
                    <p class="copyright-text">Copyright &copy; 2021 All Rights Reserved by
                        <a href="#">Abc</a>.
                    </p>
                </div>

                <div class="col-md-4 col-sm-6 col-xs-12">
                    <ul class="social-icons">
                        <li><a class="facebook" href="#"><i class="fa fa-facebook"></i></a></li>
                        <li><a class="twitter" href="#"><i class="fa fa-twitter"></i></a></li>
                        <li><a class="dribbble" href="#"><i class="fa fa-dribbble"></i></a></li>
                        <li><a class="linkedin" href="#"><i class="fa fa-linkedin"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer End -->


    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Piv4xVNRyMGpqkS2by6br4gNJ7DXjqk09RmUpJ8jgGtD7zP9yug3goQfGII0yAns"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"></script>
    <script src="https://use.fontawesome.com/c1b9851178.js"></script>

</body>

</html><?php /**PATH G:\xampp 3.0\htdocs\capstone\resources\views/joinUs.blade.php ENDPATH**/ ?>